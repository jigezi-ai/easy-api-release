class CustomException(Exception):
    def __init__(self, code, msg):
        super().__init__(msg)
        self.code = code


class ErrorCode:
    OK = 0
    ERROR_RUNWAY_EXCEPTION = 10001
    ERROR_PIKA_EXCEPTION = 10002
    NO_ITEM = 10003
    UN_SUPPORT = 10004
