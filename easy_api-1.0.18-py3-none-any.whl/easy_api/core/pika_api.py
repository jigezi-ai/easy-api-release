import json
import mimetypes
import os.path
import re
import time

import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder

from easy_api.common.cookie_utils import CookieUtils
from easy_api.common.custom_exception import CustomException, ErrorCode
from easy_api.core.video_api import VideoApi, VideoDetail, VideoGenerateOptions, VideoGenerateResult, UserResult, \
    VideoStatus, CreditResult


class PikaApi(VideoApi):

    def __init__(self):
        super().__init__('pika')
        self._base_url = 'https://api.pika.art'
        self._web_site_url = 'https://pika.art'
        self._sso_base_url = 'https://login.pika.art'

    def set_token(self, token: str = None, cookie: str = None):
        if not cookie:
            raise CustomException(code=ErrorCode.NO_ITEM, msg=f"[{self._service_name}] Empty cookie")
        self._cookie = cookie
        if not token:
            self._token = self._get_token(cookie)

    def get_user(self) -> UserResult:
        resp = self._get_user_detail()
        return UserResult(user_id=resp['id'])

    def _get_user_detail(self):
        url = self._sso_base_url + '/auth/v1/user'
        headers = self._build_headers({
            'Accept': '*/*'
        })
        resp = None
        try:
            resp = self._do_http_get(url, headers=headers)
        except CustomException as e:
            if e.status == 403:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
        return resp

    def get_credit(self) -> CreditResult:
        url = self._sso_base_url + '/rest/v1/subscriptions'
        headers = self._build_headers({
            'accept': '*/*'
        })
        user = self.get_user()

        params = {
            'select': '*',
            'user_id': f'eq.{user.user_id}'
        }
        resp = None
        try:
            resp = self._do_http_get(url, headers=headers, params=params)
        except CustomException as e:
            if e.status == 403:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
        if resp[0].get('stripe_lookup_key') == 'ultimate_monthly':
            return CreditResult(credit=(1 << 31) - 1)

        return CreditResult(credit=resp[0]['free_credits'])

    def generate_video(self, options: VideoGenerateOptions) -> VideoGenerateResult:

        user = self.get_user()

        url = self._base_url + '/generate'

        fields = None
        if options.image_path is None and options.text_prompt is None:
            raise CustomException(code=ErrorCode.NO_ITEM, msg='Either text_prompt or image_path must be provided.')
        elif options.image_path is not None and options.text_prompt is None:
            # 图片
            filename = os.path.basename(options.image_path)
            mime_type, _ = mimetypes.guess_type(options.image_path)
            image = (filename, open(options.image_path, 'rb'), mime_type)
            fields = {
                'promptText': options.text_prompt,
                'options': json.dumps({
                    "frameRate": 24,
                    "camera": {},
                    "parameters":
                        {
                            "guidanceScale": 12,
                            "motion": 1,
                            "negativePrompt": ""
                        },
                    "extend": False
                }),
                'userId': user.user_id,
                'image': image
            }
        elif options.image_path is None and options.text_prompt is not None:
            # 文本
            fields = {
                'styleId': '',
                'promptText': options.text_prompt,
                'options': json.dumps({"aspectRatio": 1.7777777777777777,
                                       "frameRate": 24,
                                       "camera": {},
                                       "parameters":
                                           {
                                               "guidanceScale": 12,
                                               "motion": 1,
                                               "negativePrompt": ""
                                           },
                                       "extend": False
                                       }),
                'userId': user.user_id
            }
        else:
            # 图片加文本
            filename = os.path.basename(options.image_path)
            mime_type, _ = mimetypes.guess_type(options.image_path)
            image = (filename, open(options.image_path, 'rb'), mime_type)
            fields = {
                'promptText': options.text_prompt,
                'options': json.dumps({"aspectRatio": 1.7777777777777777,
                                       "frameRate": 24,
                                       "camera": {},
                                       "parameters":
                                           {
                                               "guidanceScale": 12,
                                               "motion": 1,
                                               "negativePrompt": ""
                                           },
                                       "extend": False
                                       }),
                'userId': user.user_id,
                'image': image
            }

        multipart_data = MultipartEncoder(
            fields=fields)
        headers = self._build_headers({
            'Accept': '*/*',
            'Content-Type': multipart_data.content_type
        })
        resp = requests.post(url, headers=headers, data=multipart_data, timeout=(5.05, 27))
        if resp.status_code != 200:
            if resp.status_code == 403:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=resp.text, status=resp.status_code)
            raise CustomException(ErrorCode.ERROR_RUNWAY_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Response: {resp.text}")

        try:
            data = resp.json()
        except ValueError as e:
            raise CustomException(ErrorCode.ERROR_RUNWAY_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Unable to parse JSON. Response: {resp.text}") from e

        if not data.get('success', False):
            if data.get('code') == 3:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=data.get('error'))
            elif data.get('code') == 2:
                raise CustomException(code=ErrorCode.VIOLATES_POLICY, msg=data.get('error'))
            elif data.get('code') == 1:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=data.get('error'))
            raise CustomException(code=ErrorCode.ERROR_PIKA_EXCEPTION,
                                  msg=f"[{self._service_name}] The server's /generate api returned false, "
                                      f"with the message: {resp.text}")
        return VideoGenerateResult(video_id=data['data']['id'])

    def get_video_details(self, video_id, user_id: str = None) -> VideoDetail:

        url = self._web_site_url + '/my-library'
        headers = {
            'Accept': 'text/x-component',
            'Accept-Language': 'en,zh-CN;q=0.9,zh;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'Content-Type': 'text/plain;charset=UTF-8',
            'Cookie': self._cookie,
            'Next-Action': 'a4f7d00566d7755f69cb53e2b2bbaf32236f107e',  # 获取指定视频使用这个字符串
            'Origin': 'https://pika.art',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0',

        }

        data = '[{"ids":["' + video_id + '"]}]'

        result = requests.post(url, headers=headers, data=data, timeout=(5.05, 27))
        if result.status_code == 403:
            raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=result.text, status=result.status_code)

        pattern = re.compile(r'(\d+):(.+)')
        matches = pattern.findall(result.text)

        # 解析提取的键值对
        parsed_data = {}
        for key, value in matches:
            try:
                parsed_data[key] = json.loads(value)
            except json.JSONDecodeError:
                parsed_data[key] = value

        # 输出解析结果
        result_text = json.dumps(parsed_data)

        result_text_json = json.loads(result_text)
        resp = result_text_json['1']
        if not resp['success']:
            raise CustomException(code=ErrorCode.ERROR_PIKA_EXCEPTION,
                                  msg=f"[{self._service_name}] The server's /my-library api returned false, "
                                      f"with the message: {resp.text}")
        current_video = resp['data']['results'][0]['videos'][0]
        status = current_video['status']
        video_url = None
        if status == 'finished':
            video_url = current_video['resultUrl']
            ratio = 1
            status = VideoStatus.SUCCEEDED
        elif status == 'pending':
            ratio = float(current_video['progress']) / 100
            status = VideoStatus.RUNNING
        else:
            ratio = 0
            status = VideoStatus.PENDING

        return VideoDetail(ratio=ratio, video_url=video_url, status=status)

    # 构建请求头
    def _build_headers(self, new_headers: dict = None):
        if self._token is None:
            raise CustomException(code=ErrorCode.NO_ITEM, msg=f'[{self._service_name}] Token is empty,'
                                                              f'must be called the set_token method first.')
        # apikey为固定参数 --!
        apikey = ('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6'
                  'InhyY2ZhaHJ6a2pwYmxtcnNha254Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTYyNDA1M'
                  'jQsImV4cCI6MjAxMTgxNjUyNH0.2gMq3saImVLKVTDa1Ymzm28vfUG8KI7ALHBfFz9yDC8')
        headers = {
            'Accept-Language': 'en,zh-CN;q=0.9,zh;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'Apikey': apikey,
            'Authorization': self._token,
            'Origin': 'https://pika.art',
            'Referer': 'https://pika.art/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
                          ' Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0',
        }
        if new_headers:
            headers.update(new_headers)
        return headers

    def _get_token(self, cookie):

        try:
            _json_obj = CookieUtils.cookie_to_json(cookie)
            data = json.loads(_json_obj)
            if isinstance(data['sb-login-auth-token'], str):
                token = json.loads(data['sb-login-auth-token'])
            else:
                token = data['sb-login-auth-token']

            token_type = token['token_type']
            access_token = token['access_token']
            token = f'{token_type.title()} {access_token}'
        except Exception as e:
            raise CustomException(code=ErrorCode.NO_ITEM,
                                  msg=f'[{self._service_name}] Unrecognized cookie encountered. '
                                      f'Please copy and send it to the developer,current cookie:{cookie}'
                                      f',err_message:{e}')
        return token


def main():
    cookie = (
        "_ga=GA1.1.1519912370.1717662475; sb-login-auth-token=%7B%22access_token%22%3A%22eyJhbGciOiJIUzI1NiIsImtpZCI6Imw1Sm43ajRpLzFWM2ZaR2siLCJ0eXAiOiJKV1QifQ.eyJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoxNzE4MjY3Mjc0LCJpYXQiOjE3MTc2NjI0NzksImlzcyI6Imh0dHBzOi8veHJjZmFocnpranBibG1yc2Frbnguc3VwYWJhc2UuY28vYXV0aC92MSIsInN1YiI6Ijc5MzVhYzhkLTYyZTEtNGI5My04NzFmLWI2MmEwYTJiMTNiMiIsImVtYWlsIjoibG9wZXpjaGFybGVzN21AZ21haWwuY29tIiwicGhvbmUiOiIiLCJhcHBfbWV0YWRhdGEiOnsicHJvdmlkZXIiOiJkaXNjb3JkIiwicHJvdmlkZXJzIjpbImRpc2NvcmQiXX0sInVzZXJfbWV0YWRhdGEiOnsiYXZhdGFyX3VybCI6Imh0dHBzOi8vY2RuLmRpc2NvcmRhcHAuY29tL2VtYmVkL2F2YXRhcnMvMC5wbmciLCJjdXN0b21fY2xhaW1zIjp7Imdsb2JhbF9uYW1lIjoibW9oYW1tZWR6dWxhdWZrMTIyNTkifSwiZW1haWwiOiJsb3BlemNoYXJsZXM3bUBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZnVsbF9uYW1lIjoibW9oYW1tZWR6dWxhdWZrMTIyNTkiLCJpc3MiOiJodHRwczovL2Rpc2NvcmQuY29tL2FwaSIsIm5hbWUiOiJtb2hhbW1lZHp1bGF1ZmsxMjI1OSMwIiwicGhvbmVfdmVyaWZpZWQiOmZhbHNlLCJwaWN0dXJlIjoiaHR0cHM6Ly9jZG4uZGlzY29yZGFwcC5jb20vZW1iZWQvYXZhdGFycy8wLnBuZyIsInByb3ZpZGVyX2lkIjoiMTI0MTk0NTUxMzA1ODYzNTg0NiIsInN1YiI6IjEyNDE5NDU1MTMwNTg2MzU4NDYifSwicm9sZSI6ImF1dGhlbnRpY2F0ZWQiLCJhYWwiOiJhYWwxIiwiYW1yIjpbeyJtZXRob2QiOiJvYXV0aCIsInRpbWVzdGFtcCI6MTcxNzY2MjQ3OX1dLCJzZXNzaW9uX2lkIjoiZTUwYzUyMmUtYWExNy00Y2RlLWEyYzEtNGNkZmNmZDg2YzliIiwiaXNfYW5vbnltb3VzIjpmYWxzZX0.Tmt_4Mrnzj3ahEFj-EKKcTI0ANkxnbX64I6jltY6VUM%22%2C%22token_type%22%3A%22bearer%22%2C%22expires_in%22%3A604795%2C%22expires_at%22%3A1718267274%2C%22refresh_token%22%3A%22Fa6ViEBHTK2wN9w3ll-D_Q%22%2C%22user%22%3A%7B%22id%22%3A%227935ac8d-62e1-4b93-871f-b62a0a2b13b2%22%2C%22aud%22%3A%22authenticated%22%2C%22role%22%3A%22authenticated%22%2C%22email%22%3A%22lopezcharles7m%40gmail.com%22%2C%22email_confirmed_at%22%3A%222024-06-06T08%3A27%3A59.285465Z%22%2C%22phone%22%3A%22%22%2C%22confirmed_at%22%3A%222024-06-06T08%3A27%3A59.285465Z%22%2C%22last_sign_in_at%22%3A%222024-06-06T08%3A27%3A59.616459936Z%22%2C%22app_metadata%22%3A%7B%22provider%22%3A%22discord%22%2C%22providers%22%3A%5B%22discord%22%5D%7D%2C%22user_metadata%22%3A%7B%22avatar_url%22%3A%22https%3A%2F%2Fcdn.discordapp.com%2Fembed%2Favatars%2F0.png%22%2C%22custom_claims%22%3A%7B%22global_name%22%3A%22mohammedzulaufk12259%22%7D%2C%22email%22%3A%22lopezcharles7m%40gmail.com%22%2C%22email_verified%22%3Atrue%2C%22full_name%22%3A%22mohammedzulaufk12259%22%2C%22iss%22%3A%22https%3A%2F%2Fdiscord.com%2Fapi%22%2C%22name%22%3A%22mohammedzulaufk12259%230%22%2C%22phone_verified%22%3Afalse%2C%22picture%22%3A%22https%3A%2F%2Fcdn.discordapp.com%2Fembed%2Favatars%2F0.png%22%2C%22provider_id%22%3A%221241945513058635846%22%2C%22sub%22%3A%221241945513058635846%22%7D%2C%22identities%22%3A%5B%7B%22identity_id%22%3A%22db58ebaf-4de4-4d41-a836-06476e0ef197%22%2C%22id%22%3A%221241945513058635846%22%2C%22user_id%22%3A%227935ac8d-62e1-4b93-871f-b62a0a2b13b2%22%2C%22identity_data%22%3A%7B%22avatar_url%22%3A%22https%3A%2F%2Fcdn.discordapp.com%2Fembed%2Favatars%2F0.png%22%2C%22custom_claims%22%3A%7B%22global_name%22%3A%22mohammedzulaufk12259%22%7D%2C%22email%22%3A%22lopezcharles7m%40gmail.com%22%2C%22email_verified%22%3Atrue%2C%22full_name%22%3A%22mohammedzulaufk12259%22%2C%22iss%22%3A%22https%3A%2F%2Fdiscord.com%2Fapi%22%2C%22name%22%3A%22mohammedzulaufk12259%230%22%2C%22phone_verified%22%3Afalse%2C%22picture%22%3A%22https%3A%2F%2Fcdn.discordapp.com%2Fembed%2Favatars%2F0.png%22%2C%22provider_id%22%3A%221241945513058635846%22%2C%22sub%22%3A%221241945513058635846%22%7D%2C%22provider%22%3A%22discord%22%2C%22last_sign_in_at%22%3A%222024-06-06T08%3A27%3A59.281962Z%22%2C%22created_at%22%3A%222024-06-06T08%3A27%3A59.282009Z%22%2C%22updated_at%22%3A%222024-06-06T08%3A27%3A59.282009Z%22%2C%22email%22%3A%22lopezcharles7m%40gmail.com%22%7D%5D%2C%22created_at%22%3A%222024-06-06T08%3A27%3A59.276428Z%22%2C%22updated_at%22%3A%222024-06-06T08%3A27%3A59.619833Z%22%2C%22is_anonymous%22%3Afalse%7D%2C%22provider_token%22%3A%22HnQxeiZ5ybSGQsmQimMYZ8B1LwbsZz%22%2C%22provider_refresh_token%22%3A%224sqhLhFS8PMwv2IWlzU0hh1A0bmxB2%22%7D; ph_phc_POPg9pLdNURaPqBvYdOtOBO7tijCN3hQq7CGyoEbabd_posthog=%7B%22distinct_id%22%3A%227935ac8d-62e1-4b93-871f-b62a0a2b13b2%22%2C%22%24sesid%22%3A%5B1717665132835%2C%22018feca9-6128-72f0-b9d0-ced9f19692f9%22%2C1717662474536%5D%7D; _ga_GVFJVGW8G2=GS1.1.1717665108.2.1.1717665132.0.0.0\n")
    text_prompt = """red"""
    image_path = "C:/Users/Administrator/Downloads/bzrpl438uyijopbdu2fbfxilpiyxpdp3.jpeg"
    video_api = PikaApi()
    video_api.set_token(cookie=cookie)
    try:
        user = video_api.get_user()
    except CustomException as e:
        print('状态码', e.status)
        return
    print('用户信息:', user)
    credit = video_api.get_credit()
    print('当前余额:', credit)
    print('测试文本+视频生成视频')
    options = VideoGenerateOptions(text_prompt=text_prompt, image_path=image_path, is_quickly_mode=True)
    # if credit < 4:
    #     raise Exception('余额不足')
    print('创建视频任务...')
    generate_result = video_api.generate_video(options=options)
    video_id = generate_result.video_id
    print('当前视频任务ID', video_id)

    team_id = video_api.get_user().user_id
    while True:
        video_detail = video_api.get_video_details(video_id, team_id)
        print('视频详情:', video_detail)
        if video_detail.status == VideoStatus.SUCCEEDED:
            break
        time.sleep(3)
    credit = video_api.get_credit()
    print('当前余额:', credit)


if __name__ == "__main__":
    main()
