import os
import random
import time
import uuid

import requests

from easy_api.common.custom_exception import CustomException, ErrorCode
from easy_api.core.video_api import VideoApi, VideoDetail, VideoGenerateOptions, VideoGenerateResult, VideoStatus, \
    UserResult, CreditResult
from PIL import Image


class RunwayApi(VideoApi):

    def __init__(self):
        super().__init__('runway')
        self._base_url = 'https://api.runwayml.com'

    def set_token(self, token: str = None, cookie: str = None):
        self._token = token

    def get_user(self) -> UserResult:
        """
        获取用户信息
        :return:
        """
        url = self._base_url + '/v1/profile'
        headers = self._build_headers({
            'accept': '*/*'
        })
        try:
            resp = self._do_http_get(url, headers=headers)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            if e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            if e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            raise e
        if not resp['user']:
            raise CustomException(
                ErrorCode.ERROR_RUNWAY_EXCEPTION,
                f"[{self._service_name}] The server did not return user data. "
                f"Data: {resp.text}. Please check if the official /v1/profile api has changed."
            )
        user_id = resp['user']['id']
        gpu_credits = int(resp['user'].get('gpuCredits', 0))
        gpu_usage_limit = int(resp['user'].get('gpuUsageLimit', 5))

        return UserResult(user_id=user_id, gpu_credits=gpu_credits, gpu_usage_limit=gpu_usage_limit)

    def get_credit(self) -> CreditResult:
        url = self._base_url + '/v1/billing/credits_usages'
        headers = {
            'authorization': self._token
        }
        user_result = self.get_user()
        team_id = user_result.user_id
        gpu_credits = user_result.gpu_credits
        gpu_usage_limit = user_result.gpu_usage_limit
        params = {
            'asTeamId': team_id
        }
        try:
            data = self._do_http_get(url, headers=headers, params=params)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            elif e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            elif e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            elif e.status == 502:
                raise CustomException(code=ErrorCode.BAD_GATEWAY, msg=e.msg, status=e.status)
            raise e
        if len(data['creditUsages']) == 0:
            # 新账号，一次都没使用
            resp = self._get_features(team_id)
            return CreditResult(credit=int(resp['features']['permitted']['numPlanCredits']))
        new_balance = int(data['creditUsages'][0]['newBalance'])
        result = (new_balance + gpu_credits) // gpu_usage_limit
        return CreditResult(credit=result)

    def upload_image(self, image_path: str):
        #   a. 获取图片上传的地址
        filename = os.path.basename(image_path)
        build_result = self._build_image_upload_url(filename)
        url = build_result['uploadUrls'][0]
        upload_id = build_result['id']
        with open(image_path, 'rb') as file:
            image_data = file.read()

        headers = {
            'Accept': '*/*',
            'Accept-Language': 'en,zh-CN;q=0.9,zh;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'Content-type': 'image/jpeg',
            'Origin': 'https://app.runwayml.com',
            'Referer': 'https://app.runwayml.com/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
                          ' Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0',
        }
        #   b. 图片上传
        resp = requests.put(url, headers=headers, data=image_data, timeout=(5.05, 27))
        if resp.status_code != 200:
            if resp.status_code == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=resp.text, status=resp.status_code)
            raise CustomException(ErrorCode.ERROR_RUNWAY_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Response: {resp.text}")
        e_tag = resp.headers.get('Etag').strip('"')
        #   c. 获取图片链接
        image_url_result = self._get_image_url(upload_id, e_tag)
        if not image_url_result['url']:
            raise CustomException(
                ErrorCode.ERROR_RUNWAY_EXCEPTION,
                f"[{self._service_name}] The server did not return image_url data. "
                f"Data: {image_url_result}. Please check if the official /complete api has changed."
            )
        return image_url_result['url']

    def generate_video(self, options: VideoGenerateOptions) -> VideoGenerateResult:
        # 1. 如果有图片，上传图片
        #   a. 获取图片上传的地址
        #   b. 图片上传
        #   c. 获取图片链接
        image_url = None
        filename = None
        image_width = None
        image_height = None
        if options.image_path:
            image_url = self.upload_image(options.image_path)
            filename = os.path.basename(options.image_path)
            image_width, image_height = self._get_image_size(options.image_path)

        team_id = self._get_team_id()
        seed = self._random_seed()
        # 2. 创建任务
        resp = self._create_task(team_id=team_id,
                                 is_quickly_mode=options.is_quickly_mode,
                                 seed=seed,
                                 filename=filename,
                                 text_prompt=options.text_prompt,
                                 image_url=image_url)
        # 3. 生成视频
        task_id = resp['task']['id']

        self._generate_video(task_id=task_id,
                             text_prompt=options.text_prompt,
                             seed=seed,
                             image_url=image_url,
                             image_filename=filename,
                             image_width=image_width,
                             image_height=image_height)
        return VideoGenerateResult(task_id)

    # 获取任务详情
    def get_video_details(self, task_id: str, team_id: str = None) -> VideoDetail:
        # 获取任务信息
        # 完成后，获取视频链接
        if not team_id:
            raise CustomException(ErrorCode.NO_ITEM, 'Empty team_id')

        url = self._base_url + f'/v1/tasks/{task_id}?asTeamId={team_id}'
        headers = self._build_headers({
            'accept': 'application/json'
        })
        try:
            resp = self._do_http_get(url, headers=headers)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            if e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            if e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            raise e
        ratio = resp['task']['progressRatio']
        wait_time = resp['task'].get('estimatedTimeToStartSeconds')
        status = resp['task']['status']

        video_url = None
        if status == VideoStatus.SUCCEEDED:
            artifact_id = resp['task']['artifacts'][0]['id']
            filename = resp['task']['artifacts'][0]['filename']
            video_url_result = self._get_video_url(artifact_id=artifact_id, filename=filename)
            video_url = video_url_result['url']
        return VideoDetail(ratio=ratio, video_url=video_url, wait_time=wait_time, status=status)

    # 获取用户id，这里是team_id
    def _get_team_id(self):
        data = self.get_user()
        return data.user_id

    # 获取图片上传地址
    def _build_image_upload_url(self, file_name):
        """
        生成上传链接
        :return:
        """
        url = self._base_url + '/v1/uploads'
        data = {
            'filename': file_name,
            'numberOfParts': 1,
            'type': 'DATASET_PREVIEW'
        }
        headers = self._build_headers({
            'Accept': 'application/json'
        })
        try:
            resp = self._do_http_post(url, headers=headers, data=data)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            if e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            if e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            raise e
        return resp

    # 构建请求头
    def _build_headers(self, new_headers: dict = None):
        headers = {
            'Accept-Language': 'en,zh-CN;q=0.9,zh;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'Authorization': self._token,
            'Content-type': 'application/json',
            'Origin': 'https://app.runwayml.com',
            'Referer': 'https://app.runwayml.com/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
                          ' Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0',
        }
        if new_headers:
            headers.update(new_headers)
        return headers

    # 获取上传图片的云端url
    def _get_image_url(self, upload_id, e_tag):
        """
        获取图片云端url
        :param upload_id:
        :param e_tag:
        :return:
        """
        url = self._base_url + f'/v1/uploads/{upload_id}/complete'
        headers = self._build_headers({
            'accept': 'application/json'
        })
        data = {"parts": [{"PartNumber": 1, "ETag": e_tag}]}
        try:
            resp = self._do_http_post(url, headers=headers, data=data)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            if e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            if e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            raise e
        return resp

    # 创建任务
    def _create_task(self, team_id: str, is_quickly_mode: bool, seed: int,
                     filename: str = None,
                     text_prompt: str = None,
                     image_url: str = None):
        url = self._base_url + '/v1/tasks'
        headers = self._build_headers({
            'accept': 'application/json'
        })
        explore_mode = not is_quickly_mode

        data = {
            "taskType": "gen2",
            "internal": False,
            "options": {
                "name": '',
                "seconds": 4,
                "gen2Options": {
                    "mode": "gen2",
                    "seed": seed,
                    "interpolate": True,
                    "upscale": None,
                    "watermark": None,
                    "motion_score": 22,
                    "use_motion_score": True,
                    "use_motion_vectors": False,
                    "text_prompt": None,
                    "image_prompt": None,
                    "init_image": None
                },
                "exploreMode": explore_mode,
                "assetGroupName": "Gen-2"
            },
            "asTeamId": team_id
        }

        if text_prompt is None and image_url is None:
            raise CustomException(code=ErrorCode.NO_ITEM, msg='Either text_prompt or image_path must be provided.')
        elif text_prompt is not None and image_url is None:
            # 文本
            data['options']['name'] = f"Gen-2 {seed}, {text_prompt}, M 5"
            data['options']['gen2Options']['upscale'] = True
            data['options']['gen2Options']['watermark'] = False
            data['options']['gen2Options']['width'] = 1366
            data['options']['gen2Options']['height'] = 768
            data['options']['gen2Options']['text_prompt'] = text_prompt

        elif text_prompt is None and image_url is not None:
            # 图片
            data['options']['name'] = f"Gen-2 {seed}, {filename[:17]}, M 5"
            data['options']['gen2Options']['upscale'] = True
            data['options']['gen2Options']['watermark'] = False
            data['options']['gen2Options']['image_prompt'] = image_url
            data['options']['gen2Options']['init_image'] = image_url

        else:
            # 文本+图片
            data['options']['name'] = f"Gen-2 {seed}, {text_prompt}, {filename[:17]}, M 5"
            data['options']['gen2Options']['upscale'] = False
            data['options']['gen2Options']['watermark'] = True
            data['options']['gen2Options']['text_prompt'] = text_prompt
            data['options']['gen2Options']['image_prompt'] = image_url
            data['options']['gen2Options']['init_image'] = image_url
        try:
            resp = self._do_http_post(url, headers, data)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            if e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            if e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            raise e
        return resp

    # 生成随机数
    @staticmethod
    def _random_seed():
        random_int = ''.join([str(random.randint(0, 9)) for _ in range(10)])
        return int(random_int)

    # 生成视频
    def _generate_video(self, task_id, text_prompt, seed,
                        image_url: str = None, image_filename: str = None,
                        image_width: int = None, image_height: int = None):
        url = self._base_url + '/v1/generations'
        headers = self._build_headers({
            'accept': 'application/json'
        })
        # TODO id不确定
        _id = str(uuid.uuid4())
        if image_url:
            data = {
                "toolId": "gen2",
                "prompt": image_url,
                "outputs": {"outputUrls": []},
                "settings": {
                    "interpolate": True,
                    "seed": seed,
                    "upscale": False,
                    "watermark": True,
                    "imagePrompt": {
                        "url": image_url,
                        "size": {"width": image_width, "height": image_height},
                        "name": image_filename
                    },
                    "duration": 4,
                    "motionScore": 5,
                    "id": _id,
                    "taskId": task_id,
                    "textPrompt": text_prompt,
                    "loraAssetId": "",
                    "outpaintAspectRatio": "16:9",
                    "baseModel": "gen2",
                    "init_image": image_url}
            }
        else:
            data = {
                "toolId": "gen2",
                "prompt": text_prompt,
                "outputs": {"outputUrls": []},
                "settings": {
                    "interpolate": True,
                    "seed": seed,
                    "upscale": True,
                    "watermark": False,
                    "duration": 4,
                    "motionScore": 5,
                    "id": _id,
                    "taskId": task_id,
                    "textPrompt": text_prompt,
                    "style": "",
                    "aspectRatio": "16:9",
                    "outpaintAspectRatio": "16:9",
                    "baseModel": "gen2"
                }
            }
        try:
            resp = self._do_http_post(url, headers=headers, data=data)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            if e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            if e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            raise e
        return resp

    # 解析图片尺寸
    @staticmethod
    def _get_image_size(image_path):
        with Image.open(image_path) as img:
            width, height = img.size
        return width, height

    # 获取视频链接
    def _get_video_url(self, artifact_id: str, filename: str):
        url = self._base_url + f'/v1/assets/{artifact_id}/generate_download_link'
        headers = self._build_headers({
            'Accept': '*/*'
        })
        data = {"filename": filename}
        try:
            resp = self._do_http_post(url, headers=headers, data=data)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            if e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            if e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            raise e
        return resp

    # 新用户，获取额度
    def _get_features(self, team_id):
        url = self._base_url + f'/v1/profile/features?asTeamId={team_id}'
        headers = self._build_headers({
            'accept': 'application/json'
        })
        try:
            return self._do_http_get(url, headers=headers)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
            if e.status == 400:
                raise CustomException(code=ErrorCode.ACCOUNT_NOT_ENOUGH_CREDIT, msg=e.msg, status=e.status)
            if e.status == 429:
                raise CustomException(code=ErrorCode.RATE_LIMIT, msg=e.msg, status=e.status)
            raise e


# 测试
def main():
    token = (
        "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTY0MzQwMTYsImVtYWlsIjoidXJ1ZmZpbmc4NjU5QGdtYWlsLmNvbSIsImV4cCI6MTcyMDI1OTI4NC40NjEsImlhdCI6MTcxNzY2NzI4NC40NjF9.rWMcvhzAz2J6jPAa89Q47x9Vlpb9jNLSwA7Xp37Lmmw")
    text_prompt = """Animation Prompt: "Enchanted Portal"
Scene: A large, ancient door adorned with mysterious runes, surrounded by dense forest and swirling mist. 
The door slowly swings open, emitting a radiant glow shimmering with iridescent colors."""
    image_path = "C:/Users/Administrator/Downloads/bzrpl438uyijopbdu2fbfxilpiyxpdp3.jpeg"
    video_api = RunwayApi()
    video_api.set_token(token)
    try:
        user = video_api.get_user()
    except CustomException as e:
        print(e.code)
        return
    print('用户信息:', user)

    credit = video_api.get_credit()
    print('当前余额:', credit)
    print('测试文本+视频生成视频')
    options = VideoGenerateOptions(image_path=image_path, text_prompt=text_prompt, is_quickly_mode=False)
    if credit < 4:
        options.is_quickly_mode = False
    print('创建视频任务...')
    try:
        generate_result = video_api.generate_video(options=options)
    except CustomException as e:
        raise e
        return
    video_id = generate_result.video_id
    print('当前视频任务ID', video_id)
    team_id = video_api._get_team_id()

    while True:
        video_detail = video_api.get_video_details(video_id, team_id)
        print('视频详情:', video_detail)
        if video_detail.status == VideoStatus.SUCCEEDED:
            break
        time.sleep(3)
    credit = video_api.get_credit()
    print('当前余额:', credit)


if __name__ == "__main__":
    main()
