import time

import requests

from easy_api.common.custom_exception import CustomException, ErrorCode
from easy_api.core.video_api import VideoApi, VideoDetail, VideoGenerateOptions, VideoGenerateResult, UserResult, \
    VideoStatus


class LumalabsApi(VideoApi):

    def __init__(self):
        super().__init__('lumalabs')
        self._base_url = 'https://internal-api.virginia.labs.lumalabs.ai'

    def set_token(self, token: str = None, cookie: str = None):
        if token:
            raise CustomException(code=ErrorCode.UN_SUPPORT, msg=f"[{self._service_name}] Unsupported token")
        if not cookie:
            raise CustomException(code=ErrorCode.NO_ITEM, msg=f"[{self._service_name}] Empty cookie")
        self._cookie = cookie

    def get_user(self) -> UserResult:
        url = self._base_url + '/api/users/v1/me'
        headers = self._build_headers({
            'Accept': 'application/json, text/plain, */*'
        })
        resp = None
        try:
            resp = self._do_http_get(url, headers=headers)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
        return UserResult(user_id=resp['id'])

    def get_credit(self) -> int:
        url = self._base_url + '/api/photon/v1/subscription/usage'
        headers = self._build_headers({
            'Accept': 'application/json, text/plain, */*'
        })
        resp = None
        try:
            resp = self._do_http_get(url, headers=headers)
        except CustomException as e:
            if e.status == 401:
                raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=e.msg, status=e.status)
        return resp.get('available', 0)

    def generate_video(self, options: VideoGenerateOptions) -> VideoGenerateResult:
        data = {
            "aspect_ratio": "16:9",
            "expand_prompt": True
        }
        if options.image_path is None and options.text_prompt is None:
            raise CustomException(code=ErrorCode.NO_ITEM, msg='Either text_prompt or image_path must be provided.')
        elif options.image_path is not None and options.text_prompt is None:
            # 获取图片上传地址 上传图片 拿到图片链接
            image_url = self.upload_image(options.image_path)
            data.update({"user_prompt": '', 'image_url': image_url})
            pass
        elif options.image_path is None and options.text_prompt is not None:

            data.update({"user_prompt": options.text_prompt})
        else:
            # 获取图片上传地址 上传图片 拿到图片链接
            image_url = self.upload_image(options.image_path)
            data.update({"user_prompt": options.text_prompt, 'image_url': image_url})

        url = self._base_url + '/api/photon/v1/generations/'
        headers = self._build_headers({
            'Accept': 'application/json, text/plain, */*'
        })
        resp = requests.post(url, headers=headers, json=data)
        if resp.status_code == 429:
            raise CustomException(ErrorCode.RATE_LIMIT, msg=resp.text)
            # TODO 判断是无余额
        elif resp.status_code == 401:
            raise CustomException(code=ErrorCode.ACCOUNT_EXPIRED, msg=resp.text, status=resp.status_code)
        elif resp.status_code != 201:
            raise CustomException(ErrorCode.ERROR_LUMALABS_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Response: {resp.text},status_code:{resp.status_code}")

        try:
            response_json = resp.json()
        except ValueError as e:
            raise CustomException(ErrorCode.ERROR_LUMALABS_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Unable to parse JSON. Response: {resp.text}") from e
        return VideoGenerateResult(video_id=response_json[0]['id'])

    def upload_image(self, image_path) -> str:
        # 获取图片上传地址
        # 上传图片
        # 拿到图片链接
        upload_url = self._base_url + '/api/photon/v1/generations/file_upload'
        headers = self._build_headers({
            'Accept': 'application/json, text/plain, */*'
        })
        params = {
            'file_type': 'image',
            'filename': 'file.jpg'
        }
        generate_image_result = self._do_http_post(upload_url, headers, params)
        image_url = generate_image_result['public_url']
        presigned_url = generate_image_result['presigned_url']
        with open(image_path, 'rb') as file:
            image_data = file.read()
        put_heads = self._build_headers({
            'Accept': 'Accept: */*'
        })
        resp = requests.put(presigned_url, headers=put_heads, data=image_data)
        if resp.status_code != 200:
            raise CustomException(ErrorCode.ERROR_RUNWAY_EXCEPTION,
                                  f"[{self._service_name}] {presigned_url} response error. "
                                  f"Response: {resp.text}")

        return image_url

    def get_video_details(self, video_id: str, user_id: str = None) -> VideoDetail:
        url = self._base_url + '/api/photon/v1/user/generations/'
        headers = self._build_headers({
            'Accept': 'application/json, text/plain, */*'
        })
        params = {
            'offset': 0,
            'limit': 10
        }

        task_items = self._do_http_get(url, headers=headers, params=params)
        ratio = 0
        video_url = None
        status = VideoStatus.PENDING
        for item in task_items:
            if item['id'] == video_id:
                status = self.transfer_status(item['state'])
                if status == VideoStatus.RUNNING:
                    ratio = 50
                elif status == VideoStatus.SUCCEEDED:
                    ratio = 100
                    video_url = item['video']['url']
                return VideoDetail(status=status, ratio=ratio, video_url=video_url)
        return VideoDetail(status=status, ratio=ratio)

    @staticmethod
    def transfer_status(status: str) -> VideoStatus:
        if status == 'pending':
            return VideoStatus.PENDING
        elif status == 'processing':
            return VideoStatus.RUNNING
        elif status == 'completed':
            return VideoStatus.SUCCEEDED
        else:
            raise CustomException(ErrorCode.ERROR_STATUS_CODE, f'Unsupported status,status:{status}')

    def _build_headers(self, new_headers: dict = None):
        if self._cookie is None:
            raise CustomException(code=ErrorCode.NO_ITEM, msg=f'[{self._service_name}] Cookie is empty,'
                                                              f'must be called the set_token method first.')
        headers = {
            'Accept-Language': 'en,zh-CN;q=0.9,zh;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'Origin': 'https://lumalabs.ai',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
                          ' Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0',
            'Referer': 'https://lumalabs.ai/',
            'Cookie': self._cookie
        }
        if new_headers:
            headers.update(new_headers)
        return headers


def main():
    cookie = '_clck=1r680r8%7C2%7Cfmw%7C0%7C1636; _ga=GA1.1.1027515630.1719209304; access_token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOnsidXNlcl91dWlkIjoiZTdmYjg5MTctODE3NS00ZGU1LTg2YzUtMTM2ZWRmZDAzMDk3IiwiY2xpZW50X2lkIjoiIn0sImV4cCI6MTcxOTgzMzg1M30.Uqzl5bw0AWN2M9ntfgFwhtPJcwl0_U8YVwDOUMS0e3E; refresh_token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOnsidXNlcl91dWlkIjoiZTdmYjg5MTctODE3NS00ZGU1LTg2YzUtMTM2ZWRmZDAzMDk3IiwiY2xpZW50X2lkIjoiIn0sImV4cCI6MTcxOTgzMzg1M30.Uqzl5bw0AWN2M9ntfgFwhtPJcwl0_U8YVwDOUMS0e3E; _clsk=1rd7jc2%7C1719229054328%7C5%7C0%7Cx.clarity.ms%2Fcollect; _ga_67JX7C10DX=GS1.1.1719229035.3.1.1719229061.0.0.0'
    video_api = LumalabsApi()
    video_api.set_token(cookie=cookie)
    user = video_api.get_user()
    print('用户信息:', user)
    credit = video_api.get_credit()
    print('当前余额:', credit)
    generate_result = video_api.generate_video(VideoGenerateOptions(text_prompt='boy',
                                                                    image_path='/mnt/c/Users/watermelon/Downloads/3gyr8lrbeaueunnzup1rdbp5lx5ceik9.jpeg'))
    video_id = generate_result.video_id
    print('当前视频任务ID', video_id)
    print(f'start:{time.time()}')
    while True:
        video_detail = video_api.get_video_details(video_id=video_id)
        print('视频详情:', video_detail)
        if video_detail.status == VideoStatus.SUCCEEDED:
            break
        time.sleep(3)
    credit = video_api.get_credit()
    print(f'end:{time.time()}')
    print('当前余额:', credit)


if __name__ == "__main__":
    main()
