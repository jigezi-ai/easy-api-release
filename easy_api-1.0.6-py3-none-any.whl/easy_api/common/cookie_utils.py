import json
from urllib.parse import unquote, quote
import re


class CookieUtils:
    @staticmethod
    def cookie_to_json(cookie_str: str):
        # 拆分cookie字符串
        cookies = cookie_str.split('; ')
        cookie_dict = {}

        for cookie in cookies:
            key, value = cookie.split('=', 1)

            # 检查是否存在分割的字段

            match = re.match(r'^(.+)\.(\d+)$', key)
            if match:
                original_key = match.group(1)  # 获取原始cookie名称
                index = int(match.group(2))  # 获取索引
                # 如果原始cookie名称不存在于cookie字典中，创建一个新的cookie列表
                if original_key not in cookie_dict:
                    cookie_dict[original_key] = [''] * (index + 1)
                # 将值添加到原始cookie名称对应的列表中的相应索引处
                while len(cookie_dict[original_key]) <= index:
                    cookie_dict[original_key].append('')  # 确保列表足够长
                cookie_dict[original_key][index] = unquote(value)
            else:
                # 尝试解析json格式的值
                try:
                    value = json.loads(unquote(value))
                except json.JSONDecodeError:
                    value = unquote(value)

                cookie_dict[key] = value

        # 如果存在分割的字段，将其合并成单个cookie
        for key, value in cookie_dict.items():
            if isinstance(value, list):
                cookie_dict[key] = ''.join(value)

        return json.dumps(cookie_dict, indent=4)

    @staticmethod
    def json_to_cookie(json_str: str):
        cookie_dict = json.loads(json_str)
        cookies = []

        for key, value in cookie_dict.items():
            # 如果值是一个字典或列表，则将其转换为json字符串
            if isinstance(value, (dict, list)):
                value = quote(json.dumps(value))
            else:
                value = quote(str(value))
            cookies.append(f"{key}={value}")

        return '; '.join(cookies)


def main():
    # 测试
    cookie_str = '_ga=GA1.1.132195284.1717215711; sb-login-auth-token.0=%7B%22access_token%22%3A%22eyJhbGciOiJIUzI1NiIsImtpZCI6Imw1Sm43ajRpLzFWM2ZaR2siLCJ0eXAiOiJKV1QifQ.eyJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoxNzE3ODI4OTkwLCJpYXQiOjE3MTcyMjQxOTUsImlzcyI6Imh0dHBzOi8veHJjZmFocnpranBibG1yc2Frbnguc3VwYWJhc2UuY28vYXV0aC92MSIsInN1YiI6IjlhNmMwOGZjLTYyMGMtNGQyOC1hOWZlLWJhN2YwZTE2MDU1NyIsImVtYWlsIjoic3VwZXJsYWltaW5AZ21haWwuY29tIiwicGhvbmUiOiIiLCJhcHBfbWV0YWRhdGEiOnsicHJvdmlkZXIiOiJnb29nbGUiLCJwcm92aWRlcnMiOlsiZ29vZ2xlIl19LCJ1c2VyX21ldGFkYXRhIjp7ImF2YXRhcl91cmwiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NLQlZyMUMtd3Y2XzRUMlpfdzJtOWZEUXpFNVM1LXVPSmRpS1FDZEpKNm96bFdRLVE9czk2LWMiLCJlbWFpbCI6InN1cGVybGFpbWluQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJmdWxsX25hbWUiOiJNaW4gTGFpIiwiaXNzIjoiaHR0cHM6Ly9hY2NvdW50cy5nb29nbGUuY29tIiwibmFtZSI6Ik1pbiBMYWkiLCJwaG9uZV92ZXJpZmllZCI6ZmFsc2UsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NLQlZyMUMtd3Y2XzRUMlpfdzJtOWZEUXpFNVM1LXVPSmRpS1FDZEpKNm96bFdRLVE9czk2LWMiLCJwcm92aWRlcl9pZCI6IjEwNDkzMzA2NDg1NTE2NTgwODQ5NCIsInN1YiI6IjEwNDkzMzA2NDg1NTE2NTgwODQ5NCJ9LCJyb2xlIjoiYXV0aGVudGljYXRlZCIsImFhbCI6ImFhbDEiLCJhbXIiOlt7Im1ldGhvZCI6Im9hdXRoIiwidGltZXN0YW1wIjoxNzE3MjI0MTk1fV0sInNlc3Npb25faWQiOiIwYjA0NzdmZi0wZjZiLTRhNWQtOTlmMy1lMmI0OGIxMmZiM2QiLCJpc19hbm9ueW1vdXMiOmZhbHNlfQ.IJYI8T5QsfBjnnhJUd29Jqi6XBtGAmTZ3Pz-krZsW3w%22%2C%22token_type%22%3A%22bearer%22%2C%22expires_in%22%3A604795%2C%22expires_at%22%3A1717828990%2C%22refresh_token%22%3A%22hDvA4QiS4LGCnAKbNJ7btQ%22%2C%22user%22%3A%7B%22id%22%3A%229a6c08fc-620c-4d28-a9fe-ba7f0e160557%22%2C%22aud%22%3A%22authenticated%22%2C%22role%22%3A%22authenticated%22%2C%22email%22%3A%22superlaimin%40gmail.com%22%2C%22email_confirmed_at%22%3A%222024-05-07T02%3A54%3A17.41973Z%22%2C%22phone%22%3A%22%22%2C%22confirmed_at%22%3A%222024-05-07T02%3A54%3A17.41973Z%22%2C%22last_sign_in_at%22%3A%222024-06-01T06%3A43%3A15.485542171Z%22%2C%22app_metadata%22%3A%7B%22provider%22%3A%22google%22%2C%22providers%22%3A%5B%22google%22%5D%7D%2C%22user_metadata%22%3A%7B%22avatar_url%22%3A%22https%3A%2F%2Flh3.googleusercontent.com%2Fa%2FACg8ocKBVr1C-wv6_4T2Z_w2m9fDQzE5S5-uOJdiKQCdJJ6ozlWQ-Q%3Ds96-c%22%2C%22email%22%3A%22superlaimin%40gmail.com%22%2C%22email_verified%22%3Atrue%2C%22full_name%22%3A%22Min%20Lai%22%2C%22iss%22%3A%22https%3A%2F%2Faccounts.google.com%22%2C%22name%22%3A%22Min%20Lai%22%2C%22phone_verified%22%3Afalse%2C%22picture%22%3A%22https%3A%2F%2Flh3.googleusercontent.com%2Fa%2FACg8ocKBVr1C-wv6_4T2Z_w2m9fDQzE5S5-uOJdiKQCdJJ6ozlWQ-Q%3Ds96-c%22%2C%22provider_id%22%3A%22104933064855165808494%22%2C%22sub%22%3A%22104933064855165808494%22%7D%2C%22identities%22%3A%5B%7B%22identity_id%22%3A%22d5fbc0a9-d8c3-4cee-a3b9-636bcb2bc70d%22%2C%22id%22%3A%22104933064855165808494%22%2C%22user_id%22%3A%229a6c08fc-620c-4d28-a9fe-ba7f0e160557%22%2C%22identity_data%22%3A%7B%22avatar_url%22%3A%22https%3A%2F%2Flh3.googleusercontent.com%2Fa%2FACg8ocKBVr1C-wv6_4T2Z_w2m9fDQzE5S5-uOJdiKQCdJJ6ozlWQ-Q%3Ds96-c%22%2C%22email%22%3A%22superlaimin%40gmail.com%22%2C%22email_verified%22%3Atrue%2C%22full_name%22%3A%22Min%20Lai%22%2C%22iss%22%3A%22https%3A%2F%2Faccounts.google.com%22%2C%22name%22%3A%22Min%20Lai%22%2C%22phone_verified%22%3Afalse%2C%22picture%22%3A%22https%3A%2F%2Flh3.googleusercontent.com%2Fa%2FACg8ocKBVr1C-wv6_4T2Z_w2m9fDQzE5S5-uOJdiKQCdJJ6ozlWQ-Q%3Ds96-c%22%2C%22provider_id%22%3A%22104933064855165808494%22%2C%22sub%22%3A%22104933064855165808494%22%7D%2C%22provider%22%3A%22google%22%2C%22last_sign_in_at%22%3A%222024-05-07T02%3A54%3A17.414366Z%22%2C%22created_at%22%3A%222024-05-07T02%3A54%3A17.414415Z%22%2C%22updated_at%22%3A%222024-06-01T06%3A43%3A15.16125Z%22%2C%22email%22%3A%22superlaimin%40gmail.com%22%7D%5D%2C%22created_at%22%3A%222024-05-07T02%3A54%3A17.405044Z%22%2C%22updated_at%22%3A%222024-06-01T06%3A43%3A15.490662Z%22%2C%22is_anonymous%22%3Afalse%7D%2C%22provider_token%22%3A%22ya29.a0AXooCgtnIaKqscPMjHJePGqSlM3nxP7DgeKx; sb-login-auth-token.1=Oa2eRBcvXnH1VEsuU8kDiJSZpDIsHKYbSKzWzj9RO0PWi6-UBD446s5zOGtxmTke0AfRZ-c1uNQ8jDlk1zfi1JVVtSjs9tPlKRUg6gYbKjRE5A6RbgCKe2F_lQzEhN2VaCgYKAf8SARMSFQHGX2Mi6flRWzGYS7u1pkWEw5Nqnw0171%22%7D; ph_phc_POPg9pLdNURaPqBvYdOtOBO7tijCN3hQq7CGyoEbabd_posthog=%7B%22distinct_id%22%3A%229a6c08fc-620c-4d28-a9fe-ba7f0e160557%22%2C%22%24sesid%22%3A%5B1717225572932%2C%22018fd23d-fc82-796d-84df-891bdbdf51db%22%2C1717219228802%5D%7D; _ga_GVFJVGW8G2=GS1.1.1717223158.3.1.1717225573.0.0.0'
    _json_obj = CookieUtils.cookie_to_json(cookie_str)
    data = json.loads(_json_obj)
    token = json.loads(data['sb-login-auth-token'])
    token_type = token['token_type']
    access_token = token['access_token']
    token = f'{token_type.title()} {access_token}'
    print(token)


if __name__ == "__main__":
    main()
