class CustomException(Exception):
    def __init__(self, code: int, msg: str, status: int = None):
        super().__init__(msg)
        self.code = code
        self.msg = msg
        self.status = status


class ErrorCode:
    OK = 0
    ERROR_STATUS_CODE = 10000
    ERROR_RUNWAY_EXCEPTION = 10001
    ERROR_PIKA_EXCEPTION = 10002
    NO_ITEM = 10003
    UN_SUPPORT = 10004
    ACCOUNT_NOT_ENOUGH_CREDIT = 10005
    ACCOUNT_EXPIRED = 10006
    RATE_LIMIT = 10007
    ERROR_LUMALABS_EXCEPTION = 10008
    BAD_GATEWAY = 10009
