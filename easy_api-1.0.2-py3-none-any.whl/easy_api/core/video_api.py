from abc import ABC, abstractmethod
from dataclasses import dataclass

import requests

from easy_api.common.custom_exception import CustomException, ErrorCode


class VideoGenerateOptions:
    def __init__(self, text_prompt: str = None, image_path: str = None, is_quickly_mode: bool = True):
        if text_prompt is None and image_path is None:
            raise CustomException(code=ErrorCode.NO_ITEM, msg="Either text_prompt or image_path must be provided.")
        self._text_prompt = text_prompt
        self._image_path = image_path
        self._is_quickly_mode = is_quickly_mode

    @property
    def image_path(self):
        return self._image_path

    @image_path.setter
    def image_path(self, image_path):
        self._image_path = image_path

    @property
    def text_prompt(self):
        return self._text_prompt

    @text_prompt.setter
    def text_prompt(self, text_prompt):
        self._text_prompt = text_prompt

    @property
    def is_quickly_mode(self):
        return self._is_quickly_mode

    @is_quickly_mode.setter
    def is_quickly_mode(self, is_quickly_mode):
        self._is_quickly_mode = is_quickly_mode


class VideoGenerateResult:
    def __init__(self, video_id: str):
        self._video_id = video_id
        pass

    @property
    def video_id(self):
        return self._video_id

    @video_id.setter
    def video_id(self, video_id):
        self._video_id = video_id


class VideoStatus:
    PENDING = 'PENDING'
    RUNNING = 'RUNNING'
    SUCCEEDED = 'SUCCEEDED'


@dataclass
class VideoDetail:
    status: VideoStatus
    ratio: float = 0
    video_url: str = None
    wait_time: float = 0


@dataclass
class UserResult:
    user_id: str
    # runway参数: 之前剩余积分
    gpu_credits: int = 0
    # runway参数: 1秒消耗积分，默认1
    gpu_usage_limit: int = 1


class VideoApi(ABC):
    def __init__(self, service_name: str):
        self._token = None
        self._cookie = None
        self._service_name = service_name

    def _do_http_get(self, url, headers, params=None):
        resp = requests.get(url, headers=headers, params=params)
        if resp.status_code != 200:
            raise CustomException(ErrorCode.ERROR_RUNWAY_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Response: {resp.reason}")
        try:
            response_json = resp.json()
        except ValueError as e:
            raise CustomException(ErrorCode.ERROR_RUNWAY_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Unable to parse JSON. Response: {resp.text}") from e
        return response_json

    def _do_http_post(self, url, headers, data=None):
        resp = requests.post(url, headers=headers, json=data)
        if resp.status_code != 200:
            raise CustomException(ErrorCode.ERROR_RUNWAY_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Response: {resp.text}")
        try:
            response_json = resp.json()
        except ValueError as e:
            raise CustomException(ErrorCode.ERROR_RUNWAY_EXCEPTION,
                                  f"[{self._service_name}] {url} response error. "
                                  f"Unable to parse JSON. Response: {resp.text}") from e
        return response_json

    @abstractmethod
    def get_user(self) -> UserResult:
        pass

    @abstractmethod
    def set_token(self, token: str = None, cookie: str = None):
        """
        设置访问令牌
        :param cookie:
        :param token:
        :return:
        """

        pass

    @abstractmethod
    def get_credit(self) -> int:
        """
        获取账户余额
        :return:
        """
        pass

    @abstractmethod
    def generate_video(self, options: VideoGenerateOptions) -> VideoGenerateResult:
        """
        生成视频
        :param options:
        :return:
        """

        pass

    @abstractmethod
    def get_video_details(self, video_id: str, user_id: str = None) -> VideoDetail:
        """
        获取视频详情
        :param user_id:
        :param video_id:
        :return:
        """

        pass
