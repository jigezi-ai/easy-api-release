from easy_api.common.custom_exception import CustomException, ErrorCode
from easy_api.core.pika_api import PikaApi
from easy_api.core.runway_api import RunwayApi
from easy_api.core.video_api import VideoApi, VideoGenerateOptions, VideoStatus
import time


class VideoFactory:

    def get_api(self, service_name: str) -> VideoApi:
        if service_name == 'runway':
            return RunwayApi()
        elif service_name == 'pika':
            return PikaApi()
        else:
            raise CustomException(code=ErrorCode.UN_SUPPORT,
                                  msg=f"Unsupported service_name,service_name:{service_name}")


def main():
    token = ('Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.'
             'eyJpZCI6MTMzODM4OTksImVtYWlsIjoidjIuMEBxcS5jb20iLCJleHAiOjE3MTk3'
             'NjI3OTIuMzk4LCJpYXQiOjE3MTcxNzA3OTIuMzk4fQ.'
             'RkrpirHrQepw4pSZcxDJjg9Zy7PH-qODJulxua1dBo0')
    text_prompt = """Animation Prompt: "Enchanted Portal"
    Scene: A large, ancient door adorned with mysterious runes, surrounded by dense forest and swirling mist. 
    The door slowly swings open, emitting a radiant glow shimmering with iridescent colors."""
    image_path = "C:/Users/Administrator/Downloads/bzrpl438uyijopbdu2fbfxilpiyxpdp3.jpeg"
    factory = VideoFactory()
    video_api = factory.get_api('runway')
    video_api.set_token(token)

    user = video_api.get_user()
    print('用户信息:', user)
    credit = video_api.get_credit()
    print('当前余额:', credit)
    print('测试文本+视频生成视频')
    options = VideoGenerateOptions(image_path=image_path, text_prompt=text_prompt, is_quickly_mode=True)
    if credit < 4:
        options.is_quickly_mode = False
    print('创建视频任务...')
    generate_result = video_api.generate_video(options=options)
    video_id = generate_result.video_id
    print('当前视频任务ID', video_id)

    team_id = video_api._get_team_id()
    while True:
        video_detail = video_api.get_video_details(video_id, team_id)
        print('视频详情:', video_detail)
        if video_detail.status == VideoStatus.SUCCEEDED:
            break
        time.sleep(3)
    credit = video_api.get_credit()
    print('当前余额:', credit)


if __name__ == "__main__":
    main()
